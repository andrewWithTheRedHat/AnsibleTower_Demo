npm i

npm start
